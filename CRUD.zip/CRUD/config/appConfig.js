module.exports = {
    username : 'sapariyaankita',
    password : '0EQoLG7d7jWLTaa9',
    dbName : 'trycatch'
}   